const mysql = require("mysql2");
require("dotenv").config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "sistema_academico",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Exporta la versión con soporte para Promesas (async / await)
module.exports = pool.promise();


